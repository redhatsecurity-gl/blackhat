# SITE LIST :mag: :
## (1) INSTAGRAM: https://instagram.com
## (2) GIT-HUB: https://github.com
## (3) FACEBOOK: https://facebook.com
## (4) TWITTER: https://twitter.com
## (5) POKEMON-SHODOWN: https://pokemonshowdown.com
## (6) SPEEDRUN: https://www.speedrun.com
## (7) VIMEO: https://vimeo.com
## (8) PSNPROFILES: https://psnprofiles.com
## (9) INTERPALS: https://interpals.net
## (10) DAILYMOTION: https://dailymotion.com
## (11) 7CUPS: https://7cups.com
## (12) PYPY: https://pypi.org
## (13) GOOGLE-PLAY-STORE: https://play.google.com
## (14) BUYMEACOFFEE: https://buymeacoffee.com
## (15) PATREON: https://patreon.com
## (16) FLIPBOARD: https://flipboard.com
## (17) TWITCH: https://m.twitch.tv
## (18) TWITCHTRAKER: https://twitchtracker.com
## (19) LINKTREE: https://linktr.ee/
## (20) ASKFM: https://ask.fm
## (21) LOLPROFILES: https://lolprofile.net
## (22) ABOUTME: https://about.me
## (23) 9GAG: https://9gag.com
## (24) SOURCEFORGE: https://sourceforge.net
## (25) TUMBLR: https://tumblr.com
## (26) IMGUR: https://imgur.com
## (27) VKONTATKTE: https://vk.com
## (28) DEVIANTART: https://deviantart.com
## (29) YOUPIC: https://youpic.com
## (30) GFYCAT: https://gfycat.com
## (31) FLICKR: https://flickr.com
## (32) ORACLE: https://community.oracle.com
## (33) MYANIMELIST: https://myanimelist.net/
## (34) SOUNDCLOUD: https://soundcloud.com
## (35) HACKTHEBOX: https://forum.hackthebox.eu
## (36) FORTNITETRACKER: https://fortnitetracker.com
## (37) TRYHACKME: https://tryhackme.com
## (38) FLIPBOARD: https://flipboard.com
## (39) WHATPAD: https://www.wattpad.com
## (40) HEYLINK.ME: https://heylink.me
## (41) TELLONYM: https://tellonym.me
## (42) MYSPACE: https://myspace.com
## (43) PINTEREST: https://pinterest.com
## (44) DISQUS: https://disqus.com
## (45) STEAMCOMMUNITY: https://steamcommunity.com
## (46) BITCOINFORUM: https://bitcoinforum.com
## (47) BITBUCKET: https://bitbucket.org
## (48) CLUBHOUSE: https://joinclubhouse.com
## (49) BANDCAMP: https://www.bandcamp.com
## (50) BOOKCROSSING: https://www.bookcrossing.com
## (51) CHESS: https://www.chess.com
## (52) FANDOM: https://www.fandom.com
## (53) FREESOUND: https://freesound.org
## (54) PUBG: https://pubg.op.gg
## (55) EUW: "https://euw.op.gg
## (56) QUORA: https://www.quora.com
## (57) WIKIPEDIA: https://wikipedia.org
## (58) ALLMYLINKS: https://allmylinks.com
## (59) MEDIUM: https://medium.com
## (60) SKILLSHARE: https://www.skillshare.com
## (61) PR0GRAMM: https://pr0gramm.com
## (62) BINARYSEARCH: https://binarysearch.com
## (63) MIXCLOUD: https://mixcloud.com
## (64) ARCHIVE: https://archive.org
## (65) BLOGGER: https://blogspot.com
## (66) AUDIOJUNGLE: https://audiojungle.net
## (67) DOCKERHUB: https://hub.docker.com
## (68) AMINOAPPS: https://aminoapps.com
## (69) SUBLIMEFORUMS: https://forum.sublimetext.com
## (70) MINECRAFT: https://www.minecraft.net
## (71) SPLITS.IO: https://splits.io
## (72) KIK: https://kik.me
## (73) GITLAB: "https://gitlab.com
## (74) SIGNAL: https://community.signalusers.org
## (75) WIX: https://wix.com
## (76) UNSPLASH: https://unsplash.com
## (77) FACCIABUCO: https://facciabuco.com
## (78) BEHANCE: https://behance.net
## (79) HACKADAY: https://hackaday.io
## (80) ELLO: https://ello.co
## (81) JIMDO: https://jimdosite.com
## (82) KEYBASE: https://keybase.io
## (83) SLACK: https://slack.com
## (84) CAMFROG: "https://camfrog.com
## (85) YOUNOW: https://younow.com
## (86) SHITPOSTBOT5000: https://www.shitpostbot.com
## (87) SMULE: https://smule.com
## (88) OURDJTALK: https://ourdjtalk.com
## (89) NICOMMUNITYFORUM: https://www.native-instruments.com
## (90) BUZZFEED: https://buzzfeed.com
## (91) HOUSE-MIXES: https://www.house-mixes.com
## (92) OSU!: https://osu.ppy.sh
## (93) DRIBBLE: https://dribbble.com
## (94) TIKTOK: https://tiktok.com
## (95) THEHANDBOOK: https://www.thehandbook.com
## (96) LOOKBOOK: https://lookbook.nu
## (97) CODEACADEMY: https://www.codecademy.com
## (98) DEVCOMMUNITY: https://dev.to
## (99) CODEWARS: https://www.codewars.com
## (100) DRUPAL: https://www.drupal.org
## (101) SEAPORT: https://forum.pixelfederation.com
## (102) DIGGYSADVENTURE: https://forum.pixelfederation.com
## (103) TRAINSTATION: https://forum.pixelfederation.com
## (104) TRAINDTATION2: https://forum.pixelfederation.com
## (105) PORTCITY: https://forum.pixelfederation.com
## (106) VENMO: https://venmo.com
## (107) THEMEFOREST: https://themeforest.net
## (108) CBTNUGGETS: https://www.cbtnuggets.com 
## (109) PERISCOPE: https://www.pscp.tv
## (110) LIVESTREAM: https://livestream.com
## (111) KO-FI: https://ko-fi.com
## (112) LINKGENIE: https://linkgenie.co
## (113) VSCO: https://vsco.co
## (114) PASTEBIN: https://pastebin.com
## (115) RUBYGEMS: https://rubygems.org
## (116) ASCIINEMA: https://asciinema.org
## (117) MILKSHAKE: https://milkshake.app
## (118) MYMONAT: https://mymonat.com
## (119) WORDPRESS: https://{}.wordpress.com
## (120) GITEE: https://gitee.com
## (121) SCRATCH: https://scratch.mit.edu
## (122) NPM: https://www.npmjs.com
## (123) MSTDN: https://mstdn.io
## (124) HUBPAGES: https://hubpages.com
## (125) GAMESPOT: https://www.gamespot.com
## (126) OPENSOURCE: https://opensource.com
## (127) OPENSTREETMAP: https://www.openstreetmap.org
## (128) SLIDESHARE: https://slideshare.net
## (129) RATEYOURMUSIC: https://rateyourmusic.com
## (130) NOTABUH: https://notabug.org
## (131) MOIKRUG: https://career.habr.com
## (132) NEWGROUNDS: https://newgrounds.com
## (133) ROBLOX: https://www.roblox.com
## (134) LISTAL: https://www.listal.com
## (135) HACKERONE: https://hackerone.com
## (136) BUGCROWD: https://bugcrowd.com
## (137) QUOTEV: https://www.quotev.com
## (138) JOINROLL: https://joinroll.com
## (139) VBOX7: https://www.vbox7.com
## (140) BITCHUTE: https://www.bitchute.com
## (141) OPENSEA: https://opensea.io

<br>

# NSFW SITES :underage: :
## (1) YOUPORN: https://youporn.com
## (2) PORNHUB: https://pornhub.com
## (3) TINDER: https://tinder.com
## (4) CHATURBATE: https://chaturbate.com
## (5) XHAMSTER: https://xhamster.com
## (6) XVIDEOS: https://xvideos.com
## (7) BONGACAMS: https://pt.bongacams.com
## (8) LIVEJASMIN: https://livestream.com

<br>

# PHONE-NUMBER LOOKUP-SITES :iphone: :
# ITALY :it: :
## (1) PAGINEGIALLE: https://www.paginebianche.it
## (2) PAGINEBIANCHE: https://www.paginebianche.it

<br>

# USA :us: :
## (1) 411: https://www.411.com
## (2) WHITEPAGES: https://www.whitepages.com
## (3) 8080: https://800notes.com

<br>

# GERMANY :de: :
## (1) 11880: https://www.11880.com
## (2) TELEFONABC: https://www.telefonabc.at
## (3) GOYELLOW: https://www.goyellow.de

<br>

# FRANCE :fr: :
## (1) PAGESJAUNES: https://www.pagesjaunes.fr

<br>

# ROMANIA :romania: :
## (1) NUMBERVILLE: https://numberville.com
## (2) CARTETELEFONAE: https://www.carte-telefoane.info

<br>

# SWITZERLAND :switzerland: :
## (1) LOCAL : https://www.local.ch

<br>

# UNIVERSAL LOOKUP-SITES :
## (1) FREELOOKUP: https://free-lookup.net
## (2) WHOSENUMBER: https://whosenumber.info

<br>

# USERNAME SITES: 149
# PHONE-NUMBER SITES: 14
# TOTAL: 165 SITES
