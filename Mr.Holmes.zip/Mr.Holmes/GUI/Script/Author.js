/*AUTHOR: Luca Garofalo (Lucksi)
Copyright (C) 2021-2022 Lucksi
License: GNU General Public License v3.0*/

function English(){
    alert("This tool has been made by Lucksi in Sicily a small Italian island Thank you for have downloaded my Tool :)");
}

function Italiano(){
    alert("Questo tool è stato creato da Lucksi in Sicilia Grazie per aver scaricato il mio tool :)");
}

function French(){
    alert("Cette tool A été créé par Lucksi en Sicilia a petité Italien ile Merci beacoup pour avoir télécharge mon Tool :)");
}