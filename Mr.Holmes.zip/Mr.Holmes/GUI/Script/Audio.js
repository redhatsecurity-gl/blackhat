/*AUTHOR: Luca Garofalo (Lucksi)
Copyright (C) 2021-2022 Lucksi
License: GNU General Public License v3.0*/

function Play() {
    var effect = new Audio ("../Sounds/Uchiha/Sound.mp3");
    effect.play();
}